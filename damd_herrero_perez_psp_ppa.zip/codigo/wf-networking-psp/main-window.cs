﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wf_networking_psp
{
    public partial class Main : Form
    {
        ProgramStrings programStrings = new ProgramStrings();
        public Main()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            ClientConnect clientCon = new ClientConnect();
            //this.Hide();
            clientCon.Show();
        }

        private void btnServer_Click(object sender, EventArgs e)
        {
            ServerConsole server = new ServerConsole();
            server.Show();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show(programStrings.helpInfo);
        }
    }
}
