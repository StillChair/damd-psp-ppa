﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wf_networking_psp
{
    public partial class ClientConnect : Form
    {

        string ipDef = "127.0.0.1";
        int portDef = 1111;


        public ClientConnect()
        {
            InitializeComponent();
        }

        private void btnStartCon_Click(object sender, EventArgs e)
        {
            Client client = new Client();
            if (tbUser.Text != "") { client.setUser(tbUser.Text); }
            else { client.setUser("DefaultClient"); }
            this.Hide();
            if (tbAdress.Text != "")
            {
                client.startConnection(tbAdress.Text.ToString(), Convert.ToInt32(tbPort.Text));
            }
            else
            {
                client.startConnection(ipDef, portDef);
            }
            client.Show();
            this.Close();
        }
    }
}
