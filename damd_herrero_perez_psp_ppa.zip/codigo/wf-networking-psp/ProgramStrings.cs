﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wf_networking_psp
{
    internal class ProgramStrings
    {
        public string ipDef = "127.0.0.1";
        public int portDef = 1111;

        // System messages
        // ES
        public string listenEs(string ip, string port, string mode)
        {   return ($"Servidor conectado en modo [{mode}] con dirección [{ip}:{port}]{Environment.NewLine}");  }

        public string servTryConErrEs = "Hubo un error al intentar iniciar el servidor.";

        public string helpInfo = ("Gracias por descargar esta aplicación!\n\n" +
            "Para iniciar un servidor pulsa el botón 'Servidor', y\n" +
            "en la ventana que aparecerá, introduce los datos que\n" +
            "quieres que use el servidor. (También puedes dejarlos en\n" +
            "blanco, en tal caso se usarán los datos por defecto:\n" +
            "IP por defecto: 127.0.0.1\n" +
            "Puerto por defecto: 1111 ).\n\n" +
            "Para conectar un cliente pulsa el botón 'Cliente' y\n" +
            "rellena los datos del servidor al cual se va a conectar.\n" +
            "(Si se dejan en blanco se usarán los mismos datos por defecto\n" +
            "que para abrir el servidor).\n" +
            "\n" +
            "Para una guía más detallada consulte el documento\n" +
            "incluido 'como-usar'.\n");

        public string stringLeft(string str, int length)
        {
            return str.Substring(0, Math.Min(length, str.Length));
        }

    }
}
