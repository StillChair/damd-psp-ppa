﻿using SuperSimpleTcp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wf_networking_psp
{
    public partial class ServerConsole : Form
    {

        string ipDef = "127.0.0.1";
        int portDef = 1111;

        string ipStart;
        int portStart;

        bool passEn;
        string servPassword;
        string serverMode = "Default";

        bool isThreadRun = false;

        Byte[] msg;

        Thread hiloStart;

        SimpleTcpServer tcpServer;

        ProgramStrings programStrings = new ProgramStrings();



        public ServerConsole()
        {
            InitializeComponent();

            /*
            if (tcpServer.ConnectedClientsCount == 0)
            {
                textBox1.Text = ("No clients connected");
            }
            else
            {
                textBox1.Text = ("A");
            }
            */


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            hiloStart = new Thread(new ThreadStart(tryConnect));
            tcpServer = new SimpleTcpServer($"{ipDef}:{portDef}");

            msg = Encoding.UTF8.GetBytes("Mensaje del servidor!");

            updateTimer.Start();

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (cbSendOnly.Checked == true) { serverMode = "Billboard"; }
            else { serverMode = "Open"; }

            if (/*hiloStart.ThreadState != ThreadState.Running*/    isThreadRun != true)
            {

                if (tbAdress.Text != "" && tbPort.Text != "")
                {
                    ipStart = tbAdress.Text;
                    portStart = Convert.ToInt32(tbPort.Text);
                }
                else
                {
                    ipStart = ipDef;
                    portStart = portDef;
                }

                if (passEn == true) { servPassword = tbPassword.Text; }

                try { hiloStart.Start(); } catch { }

            }
            else if (isThreadRun == true)
            {   try { hiloStart.Join(); isThreadRun = false; } catch { }    }
           
        }

        public void tryConnect()
        {
            isThreadRun = true;

            IPAddress adress = IPAddress.Parse(ipStart);

            try
            {
                tcpServer = new SimpleTcpServer($"{ipStart}:{portStart}");

                tcpServer.Events.DataReceived += Events_DataReceived;
                tcpServer.Events.ClientConnected += Events_ClientConnected;

                if (tcpServer.IsListening == false)
                {   tcpServer.Start();  }
                //else { tcpServer.Dispose(); hiloStart.Join(); tcpServer.Start(); }
            }
            catch(Exception ex)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    textBox1.Text = programStrings.servTryConErrEs;
                });

                tcpServer.Dispose();
                hiloStart.Join();
                
                Console.WriteLine(ex.Message);
            }


        }

        private void Events_ClientConnected(object sender, ConnectionEventArgs e)
        {
            tcpServer.Send(e.IpPort, (passEn.ToString() + "$$$PENABLED$$$" + "#####servresp#####"));
            tcpServer.Send(e.IpPort, ("$$$MODE$$$" + serverMode + "#####servresp#####"));
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            string rec = Encoding.UTF8.GetString(e.Data.ToArray());
            if (passEn == true && rec.Contains("#####password#####"))
            {
                if (rec.Contains("#####password#####") && rec.Contains(servPassword))
                {
                    tcpServer.Send(e.IpPort, ("$$$ALLOW$$$#####servresp#####"));
                    //MessageBox.Show(e.IpPort + " - - - " + rec);
                }
                else
                {
                    tcpServer.Send(e.IpPort, ("$$$BLOCK$$$#####servresp#####"));
                    tcpServer.DisconnectClient(e.IpPort);
                }
            }
            else
            {
                if (serverMode != "Billboard")
                {
                    //var threadParameters = new System.Threading.ThreadStart(delegate { upSafe(Encoding.UTF8.GetString(e.Data.ToArray())); });
                    var threadParameters = new System.Threading.ThreadStart(delegate { upSafe(rec); });
                    var thread2 = new System.Threading.Thread(threadParameters);
                    thread2.Start();
                }
            }


        }

        private void updateTimer_Tick(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                btnServerSend.Enabled = false;
            }
            else
            {
                btnServerSend.Enabled = true;
            }
            
            //textBox1.Text = "";
            if (tcpServer.IsListening == true && tcpServer.Connections == 0)
            {
                textBox1.Text = programStrings.listenEs(ipStart, portStart.ToString(), serverMode);
            }
            if (tcpServer.Connections > 0) 
            {
                //textBox1.Text = $"Connections: {tcpServer.Connections}";
                string[] clis = tcpServer.GetClients().ToArray();
                /*
                try
                {
                    foreach (string c in clis)
                    {
                        tcpServer.Send(c, textBox1.Text);
                    }
                } catch (Exception o) { }
                */
                foreach (string c in clis)
                {
                    tcpServer.Send(c, textBox1.Text);
                }
            }
            if (cbPassword.Checked == true) { tbPassword.Visible = true; lbPassword.Visible = true; passEn = true; }
            else { tbPassword.Visible = false; lbPassword.Visible = false; }

            stlbConnStatus.Text = "Connected: " + isThreadRun.ToString();

        }

        public void upSafe(string text)
        {
            if (textBox1.InvokeRequired)
            {
                // Call this same method but append THREAD2 to the text
                Action safeWrite = delegate { upSafe(text); };
                textBox1.Invoke(safeWrite);
            }
            else textBox1.Text += $"{text} { Environment.NewLine }";
        }

        private void btnStop_Click(object sender, EventArgs e)
        {   
            if (isThreadRun == true)
            { try { stopServer(); hiloStart.Join(); isThreadRun = false; } catch { } }
            textBox1.Text += $"Servidor cerrado";
        }


        public void stopServer()
        {
            tcpServer.Stop();

            try {   foreach (string c in tcpServer.GetClients().ToArray()) { tcpServer.DisconnectClient(c); }   } catch { }

            tcpServer.Dispose();
        }

        private void btnServerSend_Click(object sender, EventArgs e)
        {
            if (isThreadRun)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    textBox1.Text += $"<Servidor> {textBox2.Text} {Environment.NewLine}";
                    textBox2.Text = "";
                });
            }
        }

        private void ServerConsole_Leave(object sender, EventArgs e)
        {
            tcpServer.Stop();
            tcpServer.Dispose();
        }
    }
}
