﻿using SuperSimpleTcp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wf_networking_psp
{
    public partial class Client : Form
    {

        Thread hiloCon;

        SimpleTcpClient tcpClient;

        string ipInput;
        int portInput;
        string user;

        bool isServPass = false;
        string serverMode = "Open";

        Boolean connected = false;

        string serverText;

        ProgramStrings ProgramStrings = new ProgramStrings();
        

        public Client()
        {
            InitializeComponent();
        }

        public void startConnection(string ip, int port)
        {
            this.ipInput = ip;
            this.portInput = port;

            hiloCon = new Thread(new ThreadStart(makeConnection));
            hiloCon.Start();
        
        }

        public void makeConnection()
        {
            try
            {
                
                tcpClient = new SimpleTcpClient(ipInput, portInput);
                tcpClient.Connect();

                tcpClient.Events.DataReceived += Events_DataReceived;
                tcpClient.Events.Connected += Events_Connected;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            
        }

        private void Client_Load(object sender, EventArgs e)
        {
            //Desactivar funcionalidad hasta que se confirme la contraseña
            updateTimer.Start();
            tbOutput.Visible = false;
            tbInput.Visible = false;
            btnSend.Enabled = false;
            //ShowMyDialogBox();

        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            string rec = Encoding.UTF8.GetString(e.Data.ToArray());


            //Revisar respuestas del servidor (#####servresp#####)
            if (rec.Contains("#####servresp#####"))
            {
                //Revisar comandos de respuesta
                if (rec.Contains("$$$ALLOW$$$"))
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        tbOutput.Visible = true;
                        tbInput.Visible = true;
                        btnSend.Enabled = true;
                    });

                    MessageBox.Show("Contraseña correcta");
                }
                else if (rec.Contains("$$$BLOCK$$$"))
                {
                    MessageBox.Show("Contraseña incorrecta");
                    this.Invoke((MethodInvoker)delegate
                    {
                        tcpClient.Disconnect();
                        tcpClient.Dispose();
                        this.Close();
                    });
                    
                }

                if (rec.Contains("$$$MODE$$$Billboard"))
                {
                    serverMode = "Billboard";
                }
                else if (rec.Contains("$$$MODE$$$Open") || rec.Contains("$$$MODE$$$Default"))
                {
                    serverMode = "Open";
                }

                //Revisar si el servidor tiene contraseña, si es asi, la pide.
                if (rec.Contains("True$$$PENABLED$$$") || rec.Contains("False$$$PENABLED$$$"))
                {
                    //try { isServPass = Convert.ToBoolean(rec.Remove(rec.Length - 32)); } catch (Exception errPass) { MessageBox.Show("Error al recibir información\ndel servidor.\n"+errPass.Message+"\n"+ rec.Remove(rec.Length - 32) + "\n" + rec); }
                    if (rec.Contains("True"))
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            tbOutput.Visible = false;
                            tbInput.Visible = false;
                            btnSend.Enabled = false;
                        });
                        ShowMyDialogBox();
                    }
                    else if (rec.Contains("False")) 
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            tbOutput.Visible = true;
                            tbInput.Visible = true;
                            btnSend.Enabled = true;
                        });
                    }
                }
            }
            

            if (tcpClient.IsConnected == true && IsHandleCreated)
            {
                try
                {
                    //tbOutput.Text = "Connected";
                    this.Invoke((MethodInvoker)delegate
                    {
                        tbOutput.Text = Encoding.UTF8.GetString(e.Data.ToArray());
                    });
                } catch (Exception ex) { MessageBox.Show(ex.Message); tcpClient.Disconnect(); tcpClient.Dispose(); }
            }
            else
            {
                tcpClient.Disconnect();
                tcpClient.Dispose();
            }
        }

        private void updateTimer_Tick(object sender, EventArgs e)
        {
            if (tbInput.Text != "")
            {   btnSend.Enabled = true;     }
            else
            {   btnSend.Enabled = false;    }

            if (connected)
            {
                switch (serverMode)
                {
                    case "Open":
                        this.Invoke((MethodInvoker)delegate
                        {
                            tbOutput.Visible = true;
                            tbInput.Visible = true;
                            btnSend.Enabled = true;
                            btnSend.Visible = true;
                        });
                        break;

                    case "Billboard":
                        this.Invoke((MethodInvoker)delegate
                        {
                            tbOutput.Visible = true;
                            tbInput.Visible = false;
                            btnSend.Enabled = false;
                            btnSend.Visible = false;
                        });
                        break;
                }
            }


        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                tcpClient.Send($"<{user}> {tbInput.Text}");
            } catch (Exception ex) { MessageBox.Show(ex.Message); }

            tbInput.Text = "";

        }

        public void setUser(string userInput) { this.user = userInput; }

        private void Client_Leave(object sender, EventArgs e)
        {

        }

        public void ShowMyDialogBox()
        {
            passwordInput testDialog = new passwordInput();

            // Show testDialog as a modal dialog and determine if DialogResult = OK.
            if (testDialog.ShowDialog() == DialogResult.OK)
            {
                // Read the contents of testDialog's TextBox.
                tcpClient.Send(testDialog.tbPass.Text + "#####password#####");
                connected = true;
            }
            else
            {
                this.Close();
            }
            testDialog.Dispose();
        }

        private void tbOutput_Leave(object sender, EventArgs e)
        {
            try
            {
                hiloCon.Join();
                tcpClient.Disconnect();
                tcpClient.Dispose();
            } catch (Exception leaveErr) { MessageBox.Show(leaveErr.Message); }
        }
    }
}
